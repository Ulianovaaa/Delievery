package com.izzzya.delievery.model

import com.google.gson.annotations.SerializedName
import kotlinx.serialization.Serializable


@Serializable
data class Meal(
    @SerializedName(value = "idMeal")
    val id: Int,
    @SerializedName(value = "strMeal")
    val name: String,
    @SerializedName(value = "strCategory")
    val category: String,
    @SerializedName(value = "strMealThumb")
    val thumbUrl: String,
    @SerializedName(value = "strInstructions")
    val instructions: String,

)
