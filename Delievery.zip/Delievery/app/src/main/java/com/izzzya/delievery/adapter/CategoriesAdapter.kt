package com.izzzya.delievery.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.RadioButton
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.izzzya.delievery.R
import com.izzzya.delievery.model.Category
import com.izzzya.delievery.network.MealsApi
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class CategoriesAdapter(private val context: Context,
                        private val dataset: List<Category>,
                        val handler: EventHandler
): RecyclerView.Adapter<CategoriesAdapter.CatViewHolder>() {

    var selectedItem: Category? = null

    interface EventHandler {
        fun handle(param: Category?)
    }

    private var handle: EventHandler? = null

    class CatViewHolder(view: View): RecyclerView.ViewHolder(view!!){
        val rb = view.findViewById<TextView>(R.id.textView)
        val cardView = view.findViewById<CardView>(R.id.cardView)
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): CatViewHolder {
        val mLayout = LayoutInflater.from(parent.context)
            .inflate(R.layout.text_row_item, parent, false)
        return CatViewHolder(mLayout)
    }

    override fun onBindViewHolder(holder: CatViewHolder, position: Int) {
        val item = dataset[position]
        fun checkColor() {
            if (item==selectedItem){
                holder.rb.setTextColor(context.getColor(R.color.red))
                holder.cardView.setCardBackgroundColor(context.getColor(R.color.red_t))
            }else{
                holder.rb.setTextColor(context.getColor(R.color.red))
                holder.cardView.setCardBackgroundColor(context.getColor(R.color.red_t))
            }
        }

        holder.rb.text = item.name

        holder.rb.setOnClickListener {
            selectedItem = item
            checkColor()
            handler.handle(item)
        }


    }

    override fun getItemCount(): Int = dataset.size
}