package com.izzzya.delievery.network

import com.izzzya.delievery.R

class PicsSource {
    companion object{
        val picsList = listOf(
            R.drawable.banner1,
            R.drawable.banner2,
            R.drawable.banner3,
            R.drawable.banner1,
            R.drawable.banner2,
            R.drawable.banner3,
        )
    }
}