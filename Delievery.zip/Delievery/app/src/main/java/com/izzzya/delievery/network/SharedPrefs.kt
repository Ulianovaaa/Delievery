package com.izzzya.delievery.network

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.izzzya.delievery.model.Category
import com.izzzya.delievery.model.Meal
import java.lang.reflect.Type

class SharedPrefs(context: Context) {
    init {
        sharedPref = context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE)

    }
    companion object{
        private var sharedPref: SharedPreferences? = null
        const val PREFERENCES = "prefs"
        private const val MEALS: String = ""
        private const val CATEGS: String = ""

        operator fun set(key: String?, value: String?) {
            val editor = sharedPref?.edit()
            editor?.putString(key, value)
            editor?.apply()
        }


        fun <Meal> setMealsList(list: List<Meal>){
            val json: String = Gson().toJson(list)
            set(MEALS, json)
        }

        fun getMealsList(): List<Meal> {
            val arrayItems: List<Meal>
            val serializedObject: String? = sharedPref?.getString(MEALS, "")
            return if (!serializedObject.isNullOrEmpty()) {
                val gson = Gson()
                val type: Type = object : TypeToken<List<Meal?>?>() {}.type
                arrayItems = gson.fromJson<List<Meal>>(serializedObject, type)
                arrayItems
            } else listOf<Meal>()
        }

        fun <Category> setCatsList(list: List<Category>){
            val json: String = Gson().toJson(list)
            set(CATEGS, json)
        }

        fun getCatsList(): List<Category> {
            val arrayItems: List<Category>
            val serializedObject: String? = sharedPref?.getString(CATEGS, "")
            return if (!serializedObject.isNullOrEmpty()) {
                val gson = Gson()
                val type: Type = object : TypeToken<List<Category?>?>() {}.type
                arrayItems = gson.fromJson<List<Category>>(serializedObject, type)
                arrayItems
            } else listOf<Category>()
        }
    }
}