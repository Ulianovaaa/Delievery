package com.izzzya.delievery.model

data class ResponseBody(val Status: String, val Message: String)