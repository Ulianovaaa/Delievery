package com.izzzya.delievery.network

import com.izzzya.delievery.model.Categories
import com.izzzya.delievery.model.Category
import com.izzzya.delievery.model.Meal
import com.izzzya.delievery.model.Meals
import com.izzzya.delievery.model.ResponseBody
import com.jakewharton.retrofit2.converter.kotlinx.serialization.asConverterFactory
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET

private const val BASE_URL =
    "https://www.themealdb.com"

private val retrofit = Retrofit.Builder()
    .addConverterFactory(GsonConverterFactory.create())
    .baseUrl(BASE_URL)
    .build()

interface MealsApiService {
    @GET("/api/json/v1/1/search.php?s")
    suspend fun getMeals(): Meals

    @GET("/api/json/v1/1/categories.php")
    suspend fun getCategories(): Categories
}

object MealsApi {
    val retrofitService: MealsApiService by lazy {
        retrofit.create(MealsApiService::class.java)
    }
}