package com.izzzya.delievery

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Adapter
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.izzzya.delievery.adapter.BannerAdapter
import com.izzzya.delievery.adapter.CategoriesAdapter
import com.izzzya.delievery.adapter.MealsAdapter
import com.izzzya.delievery.model.Category
import com.izzzya.delievery.model.Meal
import com.izzzya.delievery.network.MealsApi
import com.izzzya.delievery.network.MealsApiService
import com.izzzya.delievery.network.PicsSource
import com.izzzya.delievery.network.SharedPrefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers.Main
import kotlinx.coroutines.launch
import java.lang.Exception


class MenuFragment : Fragment(), CategoriesAdapter.EventHandler {

    private val networkNeeded = (SharedPrefs.getCatsList().isEmpty() || SharedPrefs.getMealsList().isEmpty())
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }



    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_menu, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val bannersRV = view.findViewById<RecyclerView>(R.id.bannersRV)
        val categsRV = view.findViewById<RecyclerView>(R.id.categoriesRV)
        val mealsRV = view.findViewById<RecyclerView>(R.id.mealsRV)

        bannersRV.adapter = BannerAdapter(requireContext(), PicsSource.picsList)
        if (networkNeeded){
            try {
                loadStuff()
            }catch (e: Exception){
                Toast.makeText(requireContext(), e.message, Toast.LENGTH_LONG).show()
            }
        }else{
            try {
                val cats = SharedPrefs.getCatsList()
                categsRV.adapter = CategoriesAdapter(requireContext(), cats, this@MenuFragment)
                val meals = SharedPrefs.getMealsList()
                mealsRV.adapter = MealsAdapter(requireContext(), meals)

            //getStuffFromCache(null)
            } catch (e: Exception){
                Toast.makeText(requireContext(), e.message, Toast.LENGTH_LONG).show()
            }
        }




    }

    //фильтрация тут
    override fun handle(param: Category?) {
     getStuffFromCache(param)
}

    private fun loadStuff(){
        CoroutineScope(Main).launch {
            launch {
                val cats = MealsApi.retrofitService.getCategories().categories.toList()
                SharedPrefs.setCatsList(cats)
                Log.d("cache check", SharedPrefs.getCatsList().toString())
                requireView().findViewById<RecyclerView>(R.id.categoriesRV).adapter = CategoriesAdapter(requireContext(), cats, this@MenuFragment)
            }
            launch {
                val meals = MealsApi.retrofitService.getMeals().meals
                SharedPrefs.setMealsList(meals)
                Log.d("cache check", SharedPrefs.getMealsList().toString())
                requireView().findViewById<RecyclerView>(R.id.mealsRV).adapter = MealsAdapter(requireContext(), meals)
            }
        }
    }

    private fun getStuffFromCache(param: Category?){
        val categs = SharedPrefs.getCatsList().distinctBy { it.name }
        Log.d("yo wtf", categs.toString())
        requireView().findViewById<RecyclerView>(R.id.categoriesRV).adapter = CategoriesAdapter(requireContext(), categs.distinctBy { it.name }, this@MenuFragment)
        val meals = SharedPrefs.getMealsList()
        val mealsFiltered = param?.let { meals.filter { it.category == param.name }}
        if (param == null){
            requireView().findViewById<RecyclerView>(R.id.mealsRV).adapter = MealsAdapter(requireContext(), meals)
        }else{
            requireView().findViewById<RecyclerView>(R.id.mealsRV).adapter =
                mealsFiltered?.let { MealsAdapter(requireContext(), it) }
        }

    }

}