package com.izzzya.delievery.model

import kotlinx.serialization.Serializable
import com.google.gson.annotations.SerializedName


@Serializable
data class Category(
    @SerializedName("idCategory")
    var id: String,
    @SerializedName("strCategory")
    val name: String
)
