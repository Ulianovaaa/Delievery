package com.izzzya.delievery.adapter

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.izzzya.delievery.R
import com.izzzya.delievery.model.Category
import com.izzzya.delievery.model.Meal
import com.squareup.picasso.Picasso

class MealsAdapter(private val context: Context,
                   private val dataset: List<Meal>
): RecyclerView.Adapter<MealsAdapter.MealViewHolder>() {

    class MealViewHolder(view: View): RecyclerView.ViewHolder(view!!){
        val name = view.findViewById<TextView>(R.id.mealNameTV)
        val desc = view.findViewById<TextView>(R.id.mealDescTV)
        val img = view.findViewById<ImageView>(R.id.mealImageIV)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MealViewHolder {
        val mLayout = LayoutInflater.from(parent.context)
            .inflate(R.layout.meal_item, parent, false)
        return MealViewHolder(mLayout)
    }

    override fun getItemCount(): Int = dataset.size

    override fun onBindViewHolder(holder: MealViewHolder, position: Int) {
        val item = dataset[position]

        holder.name.text = item.name
//        Log.d("meal tag", item.name)
        holder.desc.text = item.instructions
//        Log.d("meal tag", item.instructions)
        Picasso.get().load(item.thumbUrl).into(holder.img)
        Log.d("meal tag", "img loaded")

    }

}