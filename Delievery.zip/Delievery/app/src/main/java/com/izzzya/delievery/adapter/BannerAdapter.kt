package com.izzzya.delievery.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.izzzya.delievery.R

class BannerAdapter(private val context: Context,
                    private val dataset: List<Int>
): RecyclerView.Adapter<BannerAdapter.BannerViewHolder>() {

    class BannerViewHolder(view: View): RecyclerView.ViewHolder(view!!){
        val IV = view.findViewById<ImageView>(R.id.bannerIV)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BannerViewHolder {
        val mLayout = LayoutInflater.from(parent.context)
            .inflate(R.layout.banner_item, parent, false)
        return BannerViewHolder(mLayout)
    }

    override fun getItemCount(): Int =dataset.size

    override fun onBindViewHolder(holder: BannerViewHolder, position: Int) {
        val item = dataset[position]
        holder.IV.setImageResource(item)
    }

}